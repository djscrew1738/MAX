module.exports = {
  port: process.env.PORT || 3210,
  
  db: {
    connectionString: process.env.DATABASE_URL || 'postgres://max:changeme@localhost:5433/max',
  },
  
  ollama: {
    url: process.env.OLLAMA_URL || 'http://localhost:11434',
    model: process.env.OLLAMA_MODEL || 'llama3.1:8b',
    embedModel: process.env.OLLAMA_EMBED_MODEL || 'nomic-embed-text',
  },
  
  whisper: {
    url: process.env.WHISPER_URL || 'http://localhost:8100',
  },
  
  email: {
    host: process.env.SMTP_HOST || 'smtp.gmail.com',
    port: parseInt(process.env.SMTP_PORT || '587'),
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
    to: process.env.EMAIL_TO,
    from: process.env.EMAIL_FROM || 'max@ctlplumbing.com',
  },
  
  uploadDir: process.env.UPLOAD_DIR || './uploads',
  apiKey: process.env.MAX_API_KEY || 'max-secret-key-change-me',
};
