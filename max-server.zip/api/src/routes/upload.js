const express = require('express');
const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const db = require('../db');
const config = require('../config');
const { processSession } = require('../services/pipeline');

const router = express.Router();

// --- Multer config ---
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, config.uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || '.ogg';
    cb(null, `${uuidv4()}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 200 * 1024 * 1024 }, // 200MB max
});

/**
 * POST /api/upload/audio
 * Upload a recording and kick off the processing pipeline
 * 
 * Body (multipart):
 *  - audio: the audio file
 *  - job_id (optional): link to existing job
 *  - builder (optional): builder name
 *  - subdivision (optional)
 *  - lot (optional)
 *  - phase (optional)
 *  - recorded_at (optional): ISO timestamp when recording started
 */
router.post('/audio', upload.single('audio'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No audio file provided' });
    }

    console.log(`[Upload] Received audio: ${req.file.originalname} (${(req.file.size / 1024 / 1024).toFixed(1)}MB)`);

    // Create session record
    const { rows: [session] } = await db.query(
      `INSERT INTO sessions (job_id, title, phase, audio_path, status, recorded_at)
       VALUES ($1, $2, $3, $4, 'uploaded', $5)
       RETURNING id`,
      [
        req.body.job_id || null,
        req.body.title || `Walk ${new Date().toLocaleDateString()}`,
        req.body.phase || null,
        req.file.path,
        req.body.recorded_at || new Date().toISOString(),
      ]
    );

    console.log(`[Upload] Created session #${session.id}`);

    // Process async (don't block the response)
    processSession(session.id).catch(err => {
      console.error(`[Upload] Background processing failed for session ${session.id}:`, err);
    });

    res.json({
      success: true,
      session_id: session.id,
      message: 'Audio uploaded. Max is processing your recording...',
    });

  } catch (err) {
    console.error('[Upload] Error:', err);
    res.status(500).json({ error: err.message });
  }
});

/**
 * POST /api/upload/attachment
 * Upload a PDF/photo to attach to a session
 * 
 * Body (multipart):
 *  - file: the file (PDF, image)
 *  - session_id: active session to attach to
 *  - job_id (optional): job to link to
 */
router.post('/attachment', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file provided' });
    }

    const sessionId = req.body.session_id || null;
    const jobId = req.body.job_id || null;

    // Determine file type
    const ext = path.extname(req.file.originalname).toLowerCase();
    let fileType = 'document';
    if (['.pdf'].includes(ext)) fileType = 'pdf';
    if (['.jpg', '.jpeg', '.png', '.webp', '.heic'].includes(ext)) fileType = 'image';

    console.log(`[Upload] Attachment: ${req.file.originalname} (${fileType})`);

    const { rows: [attachment] } = await db.query(
      `INSERT INTO attachments (session_id, job_id, file_type, file_name, file_path, file_size)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id`,
      [sessionId, jobId, fileType, req.file.originalname, req.file.path, req.file.size]
    );

    // Trigger plan analysis for PDFs in background
    if (fileType === 'pdf') {
      const { analyzePlan } = require('../services/plans');
      analyzePlan(attachment.id).catch(err => {
        console.error(`[Upload] Plan analysis failed for attachment ${attachment.id}:`, err.message);
      });
    }

    res.json({
      success: true,
      attachment_id: attachment.id,
      file_type: fileType,
      message: `Got it! ${fileType === 'pdf' ? 'Plans' : 'Photo'} attached.`,
    });

  } catch (err) {
    console.error('[Upload] Attachment error:', err);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
