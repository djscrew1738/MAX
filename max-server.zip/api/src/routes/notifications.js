const express = require('express');
const { getUnread, markRead } = require('../services/notifications');

const router = express.Router();

/**
 * GET /api/notifications
 * Get unread notifications (for Android polling)
 */
router.get('/', async (req, res) => {
  try {
    const notifications = await getUnread();
    res.json(notifications);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/**
 * POST /api/notifications/read
 * Mark notifications as read
 * Body: { ids: [1, 2, 3] }
 */
router.post('/read', async (req, res) => {
  try {
    const { ids } = req.body;
    if (!ids || !Array.isArray(ids)) {
      return res.status(400).json({ error: 'ids array required' });
    }
    await markRead(ids);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
