package com.ctlplumbing.max.data.api

import com.ctlplumbing.max.data.models.*
import com.ctlplumbing.max.data.repository.SettingsRepository
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

class MaxApiClient(private val settings: SettingsRepository) {

    private val gson = Gson()

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS) // Long timeout for transcription
        .writeTimeout(120, TimeUnit.SECONDS) // Long timeout for upload
        .build()

    private fun baseUrl(): String = settings.getServerUrlSync().trimEnd('/')
    private fun apiKey(): String = settings.getApiKeySync()

    // ---- Upload Audio ----

    suspend fun uploadAudio(
        audioFile: File,
        jobId: Int? = null,
        title: String? = null,
        phase: String? = null,
        recordedAt: String? = null,
    ): Result<UploadResponse> = withContext(Dispatchers.IO) {
        try {
            val builder = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart(
                    "audio",
                    audioFile.name,
                    audioFile.asRequestBody("audio/ogg".toMediaType())
                )

            jobId?.let { builder.addFormDataPart("job_id", it.toString()) }
            title?.let { builder.addFormDataPart("title", it) }
            phase?.let { builder.addFormDataPart("phase", it) }
            recordedAt?.let { builder.addFormDataPart("recorded_at", it) }

            val request = Request.Builder()
                .url("${baseUrl()}/api/upload/audio")
                .header("x-api-key", apiKey())
                .post(builder.build())
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: "{}"
            
            if (response.isSuccessful) {
                Result.success(gson.fromJson(body, UploadResponse::class.java))
            } else {
                Result.failure(IOException("Upload failed (${response.code}): $body"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---- Upload Attachment ----

    suspend fun uploadAttachment(
        file: File,
        sessionId: Int? = null,
        jobId: Int? = null,
    ): Result<AttachmentResponse> = withContext(Dispatchers.IO) {
        try {
            val mimeType = when (file.extension.lowercase()) {
                "pdf" -> "application/pdf"
                "jpg", "jpeg" -> "image/jpeg"
                "png" -> "image/png"
                "webp" -> "image/webp"
                else -> "application/octet-stream"
            }

            val builder = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", file.name, file.asRequestBody(mimeType.toMediaType()))

            sessionId?.let { builder.addFormDataPart("session_id", it.toString()) }
            jobId?.let { builder.addFormDataPart("job_id", it.toString()) }

            val request = Request.Builder()
                .url("${baseUrl()}/api/upload/attachment")
                .header("x-api-key", apiKey())
                .post(builder.build())
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: "{}"

            if (response.isSuccessful) {
                Result.success(gson.fromJson(body, AttachmentResponse::class.java))
            } else {
                Result.failure(IOException("Attachment upload failed (${response.code}): $body"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---- Chat ----

    suspend fun chat(
        message: String,
        jobId: Int? = null,
        history: List<ChatMessage> = emptyList(),
    ): Result<ChatResponse> = withContext(Dispatchers.IO) {
        try {
            val chatRequest = ChatRequest(message, jobId, history)
            val jsonBody = gson.toJson(chatRequest)
                .toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url("${baseUrl()}/api/chat")
                .header("x-api-key", apiKey())
                .post(jsonBody)
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: "{}"

            if (response.isSuccessful) {
                Result.success(gson.fromJson(body, ChatResponse::class.java))
            } else {
                Result.failure(IOException("Chat failed (${response.code}): $body"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---- Jobs ----

    suspend fun getJobs(): Result<List<Job>> = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url("${baseUrl()}/api/jobs")
                .header("x-api-key", apiKey())
                .get()
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: "[]"

            if (response.isSuccessful) {
                val type = object : TypeToken<List<Job>>() {}.type
                Result.success(gson.fromJson(body, type))
            } else {
                Result.failure(IOException("Failed to get jobs (${response.code})"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getSession(sessionId: Int): Result<SessionDetail> = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url("${baseUrl()}/api/jobs/sessions/$sessionId")
                .header("x-api-key", apiKey())
                .get()
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: "{}"

            if (response.isSuccessful) {
                Result.success(gson.fromJson(body, SessionDetail::class.java))
            } else {
                Result.failure(IOException("Failed to get session (${response.code})"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---- Server Status ----

    suspend fun getStatus(): Result<ServerStatus> = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url("${baseUrl()}/status")
                .get()
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: "{}"

            if (response.isSuccessful) {
                Result.success(gson.fromJson(body, ServerStatus::class.java))
            } else {
                Result.failure(IOException("Status check failed (${response.code})"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun healthCheck(): Boolean = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url("${baseUrl()}/health")
                .get()
                .build()
            client.newCall(request).execute().isSuccessful
        } catch (e: Exception) {
            false
        }
    }
}
