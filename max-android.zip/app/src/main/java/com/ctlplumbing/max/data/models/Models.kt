package com.ctlplumbing.max.data.models

import com.google.gson.annotations.SerializedName

// --- Session / Recording ---

data class RecordingSession(
    val id: Long = 0,
    var jobId: Int? = null,
    var title: String = "",
    var phase: String? = null,
    var builderName: String? = null,
    var subdivision: String? = null,
    var lotNumber: String? = null,
    var audioFilePath: String = "",
    var status: SessionStatus = SessionStatus.RECORDING,
    var recordedAt: Long = System.currentTimeMillis(),
    var durationSecs: Int = 0,
    val attachments: MutableList<AttachmentInfo> = mutableListOf(),
    val roomMarkers: MutableList<RoomMarker> = mutableListOf(),
    val flags: MutableList<FlagMarker> = mutableListOf(),
)

enum class SessionStatus {
    RECORDING,
    STOPPED,
    QUEUED,
    UPLOADING,
    PROCESSING,
    COMPLETE,
    ERROR
}

data class AttachmentInfo(
    val filePath: String,
    val fileName: String,
    val fileType: String, // "pdf", "image"
    val addedAtSecs: Int = 0, // seconds into recording
)

data class RoomMarker(
    val name: String,
    val atSecs: Int,
)

data class FlagMarker(
    val atSecs: Int,
)

// --- API Responses ---

data class UploadResponse(
    val success: Boolean,
    @SerializedName("session_id") val sessionId: Int?,
    val message: String?,
    val error: String?,
)

data class AttachmentResponse(
    val success: Boolean,
    @SerializedName("attachment_id") val attachmentId: Int?,
    @SerializedName("file_type") val fileType: String?,
    val message: String?,
)

data class ChatRequest(
    val message: String,
    @SerializedName("job_id") val jobId: Int? = null,
    val history: List<ChatMessage> = emptyList(),
)

data class ChatResponse(
    val reply: String,
    val sources: List<ChatSource> = emptyList(),
    val error: String? = null,
)

data class ChatMessage(
    val role: String, // "user" or "assistant"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
)

data class ChatSource(
    @SerializedName("session_id") val sessionId: Int?,
    val builder: String?,
    val subdivision: String?,
    val lot: String?,
    val date: String?,
    val type: String?,
    val similarity: Float?,
)

// --- Jobs ---

data class Job(
    val id: Int,
    @SerializedName("builder_name") val builderName: String?,
    val subdivision: String?,
    @SerializedName("lot_number") val lotNumber: String?,
    val address: String?,
    val phase: String?,
    val status: String?,
    @SerializedName("fixture_count") val fixtureCount: Int?,
    @SerializedName("session_count") val sessionCount: Int?,
    @SerializedName("attachment_count") val attachmentCount: Int?,
    @SerializedName("open_items") val openItems: Int?,
    @SerializedName("job_intel") val jobIntel: String?,
    @SerializedName("created_at") val createdAt: String?,
    @SerializedName("updated_at") val updatedAt: String?,
)

data class ActionItem(
    val id: Int,
    val description: String,
    val priority: String,
    val completed: Boolean,
    @SerializedName("due_date") val dueDate: String?,
)

data class SessionDetail(
    val id: Int,
    val title: String?,
    val phase: String?,
    val transcript: String?,
    val summary: String?,
    @SerializedName("summary_json") val summaryJson: Map<String, Any>?,
    val status: String?,
    @SerializedName("recorded_at") val recordedAt: String?,
    @SerializedName("duration_secs") val durationSecs: Int?,
    @SerializedName("builder_name") val builderName: String?,
    val subdivision: String?,
    @SerializedName("lot_number") val lotNumber: String?,
    val attachments: List<AttachmentDetail>?,
    @SerializedName("action_items") val actionItems: List<ActionItem>?,
)

data class AttachmentDetail(
    val id: Int,
    @SerializedName("file_type") val fileType: String?,
    @SerializedName("file_name") val fileName: String?,
)

// --- Voice Commands ---

sealed class MaxCommand {
    data object StartRecording : MaxCommand()
    data object StopRecording : MaxCommand()
    data class AttachPlans(val timestamp: Int) : MaxCommand()
    data class TakePhoto(val timestamp: Int) : MaxCommand()
    data class NewRoom(val roomName: String, val timestamp: Int) : MaxCommand()
    data class FlagMoment(val timestamp: Int) : MaxCommand()
    data class TagJob(val rawTag: String, val timestamp: Int) : MaxCommand()
    data object Unknown : MaxCommand()
}

// --- Server Status ---

data class ServerStatus(
    val status: String,
    @SerializedName("total_sessions") val totalSessions: Int?,
    @SerializedName("completed_sessions") val completedSessions: Int?,
    @SerializedName("total_jobs") val totalJobs: Int?,
    @SerializedName("total_chunks") val totalChunks: Int?,
    @SerializedName("open_actions") val openActions: Int?,
)
