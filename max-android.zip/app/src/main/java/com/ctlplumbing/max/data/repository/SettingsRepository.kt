package com.ctlplumbing.max.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "max_settings")

class SettingsRepository(private val context: Context) {

    companion object {
        val SERVER_URL = stringPreferencesKey("server_url")
        val API_KEY = stringPreferencesKey("api_key")
        val EMAIL_TO = stringPreferencesKey("email_to")
        val WAKE_WORD_ENABLED = booleanPreferencesKey("wake_word_enabled")
        val AUTO_UPLOAD = booleanPreferencesKey("auto_upload")
        val VIBRATE_ON_COMMAND = booleanPreferencesKey("vibrate_on_command")
        val PORCUPINE_ACCESS_KEY = stringPreferencesKey("porcupine_access_key")
    }

    val serverUrl: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[SERVER_URL] ?: com.ctlplumbing.max.BuildConfig.API_BASE_URL
    }

    val apiKey: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[API_KEY] ?: com.ctlplumbing.max.BuildConfig.API_KEY
    }

    val emailTo: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[EMAIL_TO] ?: ""
    }

    val wakeWordEnabled: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[WAKE_WORD_ENABLED] ?: true
    }

    val autoUpload: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[AUTO_UPLOAD] ?: true
    }

    val vibrateOnCommand: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[VIBRATE_ON_COMMAND] ?: true
    }

    val porcupineAccessKey: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[PORCUPINE_ACCESS_KEY] ?: ""
    }

    // Sync getters for services
    fun getServerUrlSync(): String = runBlocking { serverUrl.first() }
    fun getApiKeySync(): String = runBlocking { apiKey.first() }
    fun getPorcupineKeySync(): String = runBlocking { porcupineAccessKey.first() }

    suspend fun <T> update(key: Preferences.Key<T>, value: T) {
        context.dataStore.edit { prefs ->
            prefs[key] = value
        }
    }
}
