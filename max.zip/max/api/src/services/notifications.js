const db = require('../db');

/**
 * Simple webhook/notification system
 * Stores notifications that the Android app polls for
 * 
 * In production, this could use Firebase Cloud Messaging (FCM)
 * For now, polling is simple and keeps everything self-hosted
 */

/**
 * Create a notification
 */
async function createNotification(type, title, body, data = {}) {
  await db.query(
    `INSERT INTO notifications (type, title, body, data, read)
     VALUES ($1, $2, $3, $4, FALSE)`,
    [type, title, body, JSON.stringify(data)]
  );
  console.log(`[Notify] ${type}: ${title}`);
}

/**
 * Notify that a session has been processed
 */
async function notifySessionComplete(sessionId, summaryJson) {
  const builder = summaryJson.builder_name || '';
  const subdivision = summaryJson.subdivision || '';
  const lot = summaryJson.lot_number ? `Lot ${summaryJson.lot_number}` : '';
  const parts = [builder, subdivision, lot].filter(Boolean);
  const jobLabel = parts.length > 0 ? parts.join(' — ') : `Session #${sessionId}`;

  const actionCount = summaryJson.action_items?.length || 0;
  const flagCount = summaryJson.flags?.length || 0;

  let body = `Summary ready for ${jobLabel}`;
  if (actionCount > 0) body += ` • ${actionCount} action items`;
  if (flagCount > 0) body += ` • ${flagCount} flags`;

  await createNotification('session_complete', '🔨 Job Walk Processed', body, {
    session_id: sessionId,
    action_items: actionCount,
    flags: flagCount,
  });
}

/**
 * Notify about discrepancies found
 */
async function notifyDiscrepancies(sessionId, discrepancies) {
  if (!discrepancies?.items?.length) return;

  const high = discrepancies.items.filter(d => d.severity === 'high' || d.severity === 'critical');
  
  if (high.length > 0) {
    await createNotification(
      'discrepancy',
      '⚠️ Plan Discrepancies Found',
      `${high.length} high-priority discrepancies detected. ${discrepancies.recommendation || ''}`,
      { session_id: sessionId, count: discrepancies.items.length }
    );
  }
}

/**
 * Notify about processing errors
 */
async function notifyError(sessionId, error) {
  await createNotification(
    'error',
    '❌ Processing Failed',
    `Session #${sessionId}: ${error}`,
    { session_id: sessionId }
  );
}

/**
 * Get unread notifications
 */
async function getUnread() {
  const { rows } = await db.query(
    `SELECT * FROM notifications WHERE read = FALSE ORDER BY created_at DESC LIMIT 50`
  );
  return rows;
}

/**
 * Mark notifications as read
 */
async function markRead(notificationIds) {
  if (!notificationIds || notificationIds.length === 0) return;
  await db.query(
    `UPDATE notifications SET read = TRUE WHERE id = ANY($1)`,
    [notificationIds]
  );
}

module.exports = {
  createNotification,
  notifySessionComplete,
  notifyDiscrepancies,
  notifyError,
  getUnread,
  markRead,
};
